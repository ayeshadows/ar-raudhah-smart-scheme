import express from "express";
import { createServer as createViteServer } from "vite";
import Database from "better-sqlite3";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const db = new Database("pintar.db");

// Initialize Database
db.exec(`
  CREATE TABLE IF NOT EXISTS members (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nric_last4 TEXT UNIQUE,
    status TEXT,
    tier TEXT,
    membership_number TEXT,
    start_date TEXT,
    next_payment_date TEXT,
    next_payment_amount TEXT,
    points INTEGER DEFAULT 0
  )
`);

// Seed data if empty
const rowCount = db.prepare("SELECT count(*) as count FROM members").get() as { count: number };
if (rowCount.count === 0) {
  const insert = db.prepare(`
    INSERT INTO members (nric_last4, status, tier, membership_number, start_date, next_payment_date, next_payment_amount, points)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `);
  insert.run("123A", "Active", "Skim Pintar Plus", "SPP-2024-001", "2024-01-01", "2026-04-01", "$20.00", 0);
  insert.run("456B", "Submitted", "Skim Pintar", null, null, null, null, 0);
  insert.run("789C", "Payment Failed", "Skim Pintar", "SP-2024-042", "2024-02-15", "2026-03-01", "$5.00", 0);
  insert.run("000D", "Verified", "Skim Pintar", null, null, "2026-03-15", "$5.00", 0);
  insert.run("999E", "Cancelled", "Skim Pintar", "SP-2023-999", "2023-05-10", null, null, 0);
  insert.run("575G", "Active Member", "Skim Pintar", "SP-2024-575", "2024-03-01", "14 March", "$5.00", 10);
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Routes
  app.get("/api/member/:nric", (req, res) => {
    const nric = req.params.nric.toUpperCase();
    const member = db.prepare("SELECT * FROM members WHERE nric_last4 = ?").get(nric) as any;
    if (member) {
      // Check for 7-day reminder
      if (member.next_payment_date) {
        const today = new Date("2026-03-07"); // Using the fixed current time provided in metadata
        today.setHours(0, 0, 0, 0);
        
        let pDate: Date | null = null;
        // Try to parse the date. If it's "14 March", assume current year 2026
        if (member.next_payment_date.includes(" ") && !member.next_payment_date.includes("-")) {
           pDate = new Date(`${member.next_payment_date} 2026`);
        } else {
           pDate = new Date(member.next_payment_date);
        }

        if (pDate && !isNaN(pDate.getTime())) {
          pDate.setHours(0, 0, 0, 0);
          const diffTime = pDate.getTime() - today.getTime();
          const diffDays = Math.round(diffTime / (1000 * 60 * 60 * 24));
          if (diffDays === 7) {
            member.trigger_reminder = true;
          }
        }
      }
      res.json(member);
    } else {
      res.status(404).json({ error: "Member not found" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(__dirname, "dist", "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
