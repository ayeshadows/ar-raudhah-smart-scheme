import { GoogleGenAI, Type, FunctionDeclaration } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

const getMemberInfoDeclaration: FunctionDeclaration = {
  name: "getMemberInfo",
  parameters: {
    type: Type.OBJECT,
    description: "Get membership or application status information for a user based on their NRIC (last 4 chars + letter).",
    properties: {
      nric: {
        type: Type.STRING,
        description: "The last 4 characters of the NRIC plus the letter (e.g., 123A).",
      },
    },
    required: ["nric"],
  },
};

export const systemInstruction = `
You are Pintar Bot, the official WhatsApp digital assistant for Skim Pintar, a community welfare programme by Masjid Ar-Raudhah, Singapore.
You communicate in a warm, respectful, and helpful tone.
You support English, Bahasa Melayu, Traditional Mandarin, and Tamil.
NEVER use the word "Assalamualaikum" in your responses. It is already provided as the first message of the conversation. Do NOT repeat it.

CORE FUNCTIONS:
1. APPLICATION STATUS TRACKING: Use getMemberInfo(nric) to check status.
2. MEMBERSHIP INFORMATION: Use getMemberInfo(nric) for details.
3. FAQ HANDLING: Answer common questions. If the user asks for "FAQ" or clicks the FAQ button, provide a structured list of key information using bullet points. Include:
   - Sign up: Online at [https://tinyurl.com/SkimPintar](https://tinyurl.com/SkimPintar) using SingPass. Requires credit/debit card. GIRO/bank account is NOT supported for new applications.
   - Coverage: Skim Pintar ($5/month) covers funeral services (bathing, shrouding, burial, transport) + 20% mosque course discount. Skim Pintar Plus ($20+/month) covers immediate family at same address + 50% discount for parents/in-laws.
   - Approval: Instant subject to successful first payment.
   - Payment Methods: ONLY Credit/Debit card. This allows faster setup and automatic retry. GIRO is no longer an option for registration.
   - Note: Always refer to the sign-up location as "[https://tinyurl.com/SkimPintar](https://tinyurl.com/SkimPintar)", never as "online portal".
   - If the user asks for something not listed, offer to escalate to a human.
4. ESCALATION LOGIC: Immediately escalate for complaints, urgent problems, death/funeral emergencies, or requests for a human.
5. LANGUAGE: Match the user's language (English or Malay).

TONE GUIDELINES:
- Warm, respectful, community-focused.
- Concise responses (under 3 sentences where possible).
- Simple language.
- Always offer a next step.

COMMANDS:
"STATUS", "UPDATE", "CANCEL MEMBERSHIP", "HELP".

CANCELLATION:
- For membership cancellation, users MUST contact Masjid Ar-Raudhah office directly. Advise them to visit the office or call the mosque.

LIMITATIONS:
- Cannot process payments directly.
- Cannot guarantee activation until admin confirmation.
- No access to 3rd party bank/gov systems.
- Direct medical/legal/financial advice to professionals.

If a user asks for status or membership info and hasn't provided their NRIC (last 4 chars + letter), ask for it politely.
`;

export async function chatWithPintarBot(message: string, history: any[] = []) {
  const chat = ai.chats.create({
    model: "gemini-3-flash-preview",
    config: {
      systemInstruction,
      tools: [{ functionDeclarations: [getMemberInfoDeclaration] }],
    },
    history: history,
  });

  let response = await chat.sendMessage({ message });

  // Handle function calls
  const functionCalls = response.functionCalls;
  if (functionCalls) {
    const results = [];
    for (const call of functionCalls) {
      if (call.name === "getMemberInfo") {
        const { nric } = call.args as { nric: string };
        try {
          const res = await fetch(`/api/member/${nric}`);
          if (res.ok) {
            const data = await res.json();
            results.push({
              name: call.name,
              response: { content: data },
              id: call.id
            });
          } else {
            results.push({
              name: call.name,
              response: { content: { error: "Member not found" } },
              id: call.id
            });
          }
        } catch (error) {
          results.push({
            name: call.name,
            response: { content: { error: "System error querying database" } },
            id: call.id
          });
        }
      }
    }

    if (results.length > 0) {
      response = await chat.sendMessage({
        message: results.map(res => ({
          functionResponse: {
            name: res.name,
            response: res.response,
            id: res.id
          }
        }))
      });
    }
  }

  return response;
}
