import React, { useState, useRef, useEffect } from 'react';
import { Send, User, Bot, HelpCircle, CreditCard, RefreshCw, XCircle, MessageSquare, Phone, AlertTriangle, FileText } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { chatWithPintarBot } from './services/geminiService';

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'bot';
  timestamp: Date;
}

export default function App() {
  const [language, setLanguage] = useState<'en' | 'ms' | 'zh' | 'ta' | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [history, setHistory] = useState<any[]>([]);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const initChat = (lang: 'en' | 'ms' | 'zh' | 'ta') => {
    setLanguage(lang);
    let initialText = 'Assalamualaikum! How can I help you? (Please select the buttons below)';
    
    if (lang === 'ms') {
      initialText = 'Assalamualaikum! Bagaimana saya boleh membantu anda? (Sila pilih butang di bawah)';
    } else if (lang === 'zh') {
      initialText = 'Assalamualaikum! 我可以如何幫助您？（請選擇下面的按鈕）';
    } else if (lang === 'ta') {
      initialText = 'Assalamualaikum! நான் உங்களுக்கு எப்படி உதவ முடியும்? (தயவுசெய்து கீழே உள்ள பொத்தான்களைத் தேர்ந்தெடுக்கவும்)';
    }
    
    setMessages([
      {
        id: '1',
        text: initialText,
        sender: 'bot',
        timestamp: new Date(),
      },
    ]);
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (language) {
      scrollToBottom();
    }
  }, [messages, language]);

  const handleSend = async (e?: React.FormEvent, textOverride?: string) => {
    e?.preventDefault();
    const messageText = textOverride || input;
    if (!messageText.trim() || isLoading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      text: messageText,
      sender: 'user',
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    // Hardcoded response for specific user ID 575G
    if (messageText.trim().toUpperCase() === '575G') {
      setTimeout(() => {
        const botMessage: Message = {
          id: (Date.now() + 1).toString(),
          text: "**Status**: Active Member\n**Next Payment**: 30 April\n**Point balance**: 10 points\nPlease visit the website to use your points",
          sender: 'bot',
          timestamp: new Date(),
        };
        setMessages((prev) => [...prev, botMessage]);
        setIsLoading(false);
      }, 1000); // Add a small delay for realism
      return;
    }

    try {
      // Add language context to the first message if history is empty
      const langMap = {
        en: 'English',
        ms: 'Malay',
        zh: 'Traditional Mandarin',
        ta: 'Tamil'
      };
      const prompt = history.length === 0 
        ? `[Language Preference: ${langMap[language!]}] ${messageText}`
        : messageText;

      const response = await chatWithPintarBot(prompt, history);
      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: response.text || "I'm sorry, I couldn't process that. Please try again.",
        sender: 'bot',
        timestamp: new Date(),
      };

      setMessages((prev) => [...prev, botMessage]);
      
      // Update history for context
      setHistory(prev => [
        ...prev,
        { role: 'user', parts: [{ text: messageText }] },
        { role: 'model', parts: [{ text: response.text || "" }] }
      ]);
    } catch (error) {
      console.error('Chat error:', error);
      let errorText = 'Sorry, there was a system error. Please try again later.';
      
      if (language === 'ms') {
        errorText = 'Maaf, terdapat ralat sistem. Sila cuba sebentar lagi.';
      } else if (language === 'zh') {
        errorText = '抱歉，系統出錯。請稍後再試。';
      } else if (language === 'ta') {
        errorText = 'மன்னிக்கவும், கணினி பிழை ஏற்பட்டது. பின்னர் மீண்டும் முயற்சிக்கவும்.';
      }
      
      setMessages((prev) => [
        ...prev,
        {
          id: (Date.now() + 1).toString(),
          text: errorText,
          sender: 'bot',
          timestamp: new Date(),
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const quickActions = [
    { label: 'STATUS', icon: <RefreshCw size={16} /> },
    { label: 'UPDATE', icon: <MessageSquare size={16} /> },
    { label: 'CANCEL MEMBERSHIP', icon: <XCircle size={16} /> },
    { label: 'FAQ', icon: <FileText size={16} /> },
    { label: 'HELP', icon: <HelpCircle size={16} /> },
  ];

  if (!language) {
    return (
      <div className="flex flex-col h-screen bg-[#efeae2] font-sans items-center justify-center p-6">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white p-8 rounded-2xl shadow-xl max-w-sm w-full text-center"
        >
          <div className="w-16 h-16 bg-[#075e54] rounded-full flex items-center justify-center mx-auto mb-6 text-white">
            <Bot size={32} />
          </div>
          <h1 className="text-2xl font-bold text-gray-800 mb-2">Pintar Bot</h1>
          <p className="text-gray-500 mb-8">Please select your preferred language / Sila pilih bahasa pilihan anda</p>
          
          <div className="grid grid-cols-1 gap-3">
            <button 
              onClick={() => initChat('en')}
              className="w-full py-3 px-4 bg-[#075e54] text-white rounded-xl font-semibold hover:bg-[#054c44] transition-colors flex items-center justify-center gap-2"
            >
              English
            </button>
            <button 
              onClick={() => initChat('ms')}
              className="w-full py-3 px-4 bg-white border-2 border-[#075e54] text-[#075e54] rounded-xl font-semibold hover:bg-emerald-50 transition-colors flex items-center justify-center gap-2"
            >
              Bahasa Melayu
            </button>
            <button 
              onClick={() => initChat('zh')}
              className="w-full py-3 px-4 bg-white border-2 border-[#075e54] text-[#075e54] rounded-xl font-semibold hover:bg-emerald-50 transition-colors flex items-center justify-center gap-2"
            >
              繁體中文 (Mandarin)
            </button>
            <button 
              onClick={() => initChat('ta')}
              className="w-full py-3 px-4 bg-white border-2 border-[#075e54] text-[#075e54] rounded-xl font-semibold hover:bg-emerald-50 transition-colors flex items-center justify-center gap-2"
            >
              தமிழ் (Tamil)
            </button>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-screen bg-[#efeae2] font-sans">
      {/* Header */}
      <header className="bg-[#075e54] text-white p-4 shadow-md flex items-center gap-3">
        <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
          <Bot size={24} />
        </div>
        <div>
          <h1 className="font-bold text-lg leading-tight">Pintar Bot</h1>
          <p className="text-xs text-emerald-100">Official Skim Pintar Assistant</p>
        </div>
      </header>

      {/* Chat Area */}
      <main className="flex-1 overflow-y-auto p-4 space-y-4 scrollbar-hide">
        <div className="max-w-2xl mx-auto">
          <AnimatePresence initial={false}>
            {messages.map((msg) => (
              <motion.div
                key={msg.id}
                initial={{ opacity: 0, y: 10, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'} mb-4`}
              >
                <div
                  className={`max-w-[85%] p-3 rounded-lg shadow-sm relative ${
                    msg.sender === 'user'
                      ? 'bg-[#dcf8c6] text-gray-800 rounded-tr-none'
                      : 'bg-white text-gray-800 rounded-tl-none'
                  }`}
                >
                  <div className="text-sm md:text-base leading-relaxed">
                    <ReactMarkdown 
                      remarkPlugins={[remarkGfm]}
                      components={{
                        a: ({ node, ...props }) => (
                          <a 
                            {...props} 
                            target="_blank" 
                            rel="noopener noreferrer" 
                            className="text-blue-600 underline hover:text-blue-800 break-all"
                          />
                        ),
                        p: ({ node, ...props }) => <p {...props} className="mb-2 last:mb-0 whitespace-pre-wrap" />
                      }}
                    >
                      {msg.text}
                    </ReactMarkdown>
                  </div>
                  <div className="text-[10px] text-gray-500 text-right mt-1">
                    {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </div>
                  {/* Bubble tail */}
                  <div
                    className={`absolute top-0 w-2 h-2 ${
                      msg.sender === 'user'
                        ? 'right-[-8px] border-l-[8px] border-l-[#dcf8c6] border-b-[8px] border-b-transparent'
                        : 'left-[-8px] border-r-[8px] border-r-white border-b-[8px] border-b-transparent'
                    }`}
                  />
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
          {isLoading && (
            <div className="flex justify-start mb-4">
              <div className="bg-white p-3 rounded-lg rounded-tl-none shadow-sm flex gap-1">
                <span className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                <span className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                <span className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>
      </main>

      {/* Quick Actions */}
      <div className="bg-white/50 backdrop-blur-sm p-2 border-t border-gray-200 overflow-x-auto no-scrollbar">
        <div className="flex gap-2 max-w-2xl mx-auto px-2 min-w-max">
          {quickActions.map((action) => (
            <button
              key={action.label}
              onClick={() => handleSend(undefined, action.label)}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-gray-300 rounded-full text-xs font-medium text-gray-700 hover:bg-emerald-50 hover:border-emerald-200 transition-colors whitespace-nowrap shadow-sm"
            >
              {action.icon}
              {action.label}
            </button>
          ))}
        </div>
      </div>

      {/* Input Area */}
      <footer className="bg-[#f0f0f0] p-3 border-t border-gray-300">
        <form
          onSubmit={handleSend}
          className="max-w-2xl mx-auto flex items-center gap-2"
        >
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Type a message..."
            className="flex-1 bg-white p-3 rounded-full border-none focus:ring-2 focus:ring-[#075e54] text-sm shadow-inner"
          />
          <button
            type="submit"
            disabled={!input.trim() || isLoading}
            className="w-12 h-12 bg-[#075e54] text-white rounded-full flex items-center justify-center shadow-md hover:bg-[#054c44] disabled:bg-gray-400 transition-colors"
          >
            <Send size={20} />
          </button>
        </form>
        <p className="text-[10px] text-center text-gray-500 mt-2">
          Pintar Bot can make mistakes. Check important info.
        </p>
      </footer>
    </div>
  );
}
